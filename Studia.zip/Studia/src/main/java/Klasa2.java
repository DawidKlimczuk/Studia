package com.mojaaplikacja.pakiet2;

public class Klasa2 {
    private int liczba;

    public Klasa2(int liczba) {
        this.liczba = liczba;
    }

    public void wykonajAkcje() {
        System.out.println("Wykonano akcję w klasie 2: " + liczba);
    }
}